#Requires -Version 5.1
<#
  One-time setup using Azure CLI (>= 2.75) and its Azure Automation extension.
  Prerequisite: create a Teams Workflows 'Send webhook alerts to a channel' flow
  and copy its webhook URL. You need Azure permission to create an Automation account.
  Runs a public-host certificate check daily, with no self-hosted VM.
#>
$ErrorActionPreference = 'Stop'
$runbookName  = 'Check-PublicTlsExpiry'
$scheduleName = 'PublicTlsExpiry-Daily'
$api = '2023-11-01'

function Require-Input([string]$label) {
    $value = Read-Host $label
    if ([string]::IsNullOrWhiteSpace($value)) { throw "$label is required." }
    return $value.Trim()
}
function Must-Succeed([string]$description) {
    if ($LASTEXITCODE -ne 0) { throw "$description failed (exit $LASTEXITCODE). See Azure CLI error output." }
    Write-Host "OK: $description" -ForegroundColor Green
}
function Put-Json([string]$url, [object]$value) {
    $tmp = [System.IO.Path]::GetTempFileName()
    try {
        $json = $value | ConvertTo-Json -Depth 15
        [System.IO.File]::WriteAllText($tmp, $json, [System.Text.UTF8Encoding]::new($false))
        & az rest --method put --url $url --headers 'Content-Type=application/json' --body "@$tmp" --output none
        Must-Succeed "PUT $(([uri]$url).AbsolutePath.Split('/')[-1])"
    }
    finally { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
}

Write-Host "`nCertificate expiry monitor: Azure Automation + Microsoft Teams" -ForegroundColor Cyan
Write-Host 'Provide all inputs now. You will review them before resources are created.'
$subscription = Require-Input 'Azure subscription name or ID'
$rg = Require-Input 'Existing resource group name (for monitoring resources)'
$account = Require-Input 'New Automation account name (globally unique in Azure region context)'
$site = Require-Input 'PUBLIC TLS hostname, without https:// (e.g. www.example.com)'
if ($site -notmatch '^[A-Za-z0-9.-]+$' -or $site.StartsWith('-') -or $site.Contains('..')) {
    throw 'Hostname must be a bare DNS name, e.g. www.example.com.'
}
# Hide the secret at the prompt; never print it to the console.
$webhookSecret = Read-Host 'Teams Workflows webhook URL (input hidden)' -AsSecureString
if (-not $webhookSecret -or $webhookSecret.Length -eq 0) { throw 'Teams Workflows webhook URL is required.' }
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($webhookSecret)
try { $webhook = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
$webhookSecret = $null
if ($webhook -notmatch '^https://') { throw 'Teams webhook must begin with https://' }
$warningIn = Read-Host 'Initial warning days [30]'
$warningDays = if ($warningIn) { [int]$warningIn } else { 30 }
$escalationIn = Read-Host 'Daily escalation days [10]'
$escalationDays = if ($escalationIn) { [int]$escalationIn } else { 10 }
if ($warningDays -le 0 -or $escalationDays -le 0 -or $escalationDays -gt $warningDays) {
    throw 'Thresholds must be positive, and escalation days must be <= warning days.'
}
$doTest = (Read-Host 'Send one setup test to Teams now? [Y/n]') -notmatch '^[nN]'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$runbookFile = Join-Path $here 'Check-CertExpiry-Runbook.ps1'
if (-not (Test-Path -LiteralPath $runbookFile -PathType Leaf)) { throw "Runbook file missing: $runbookFile" }
if (-not (Get-Command az -ErrorAction SilentlyContinue)) { throw 'Azure CLI is not installed or not on PATH.' }
# Avoid JMESPath quoting problems with the hyphenated JSON key "azure-cli" in Windows PowerShell.
$azVersionRaw = & az version --output json
$azVersionExit = $LASTEXITCODE
if ($azVersionExit -ne 0) { throw "Azure CLI check failed (exit $azVersionExit)." }
$azVersionJson = ($azVersionRaw -join [Environment]::NewLine)
$azVersionObject = $azVersionJson | ConvertFrom-Json
$azVersion = [string]$azVersionObject.'azure-cli'
if ([string]::IsNullOrWhiteSpace($azVersion)) { throw 'Unable to read Azure CLI version from az version output.' }
Write-Host "OK: Azure CLI check ($azVersion)" -ForegroundColor Green
if ([version]$azVersion -lt [version]'2.75.0') { throw "Azure CLI version $azVersion is too old; upgrade it to 2.75.0+." }

& az account show --output none 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host 'Azure CLI login required.'
    & az login --output none
    Must-Succeed 'Azure login'
}
& az account set --subscription $subscription
Must-Succeed 'Select subscription'
$subIdRaw = & az account show --query id -o tsv
Must-Succeed 'Read subscription ID'
$subId = (($subIdRaw -join [Environment]::NewLine).Trim())
if ([string]::IsNullOrWhiteSpace($subId)) { throw 'Azure CLI returned an empty subscription ID.' }
$regionRaw = & az group show --name $rg --query location -o tsv
Must-Succeed 'Verify existing resource group'
$region = (($regionRaw -join [Environment]::NewLine).Trim())
if ([string]::IsNullOrWhiteSpace($region)) { throw "Resource group '$rg' returned an empty location." }
$root = "/subscriptions/$subId/resourceGroups/$rg/providers/Microsoft.Automation/automationAccounts/$account"
# Resource listing succeeds even when no Automation account exists.
$accountPresentRaw = & az resource list --resource-group $rg --resource-type 'Microsoft.Automation/automationAccounts' --query "[?name=='$account'].name | [0]" -o tsv
Must-Succeed 'Check whether Automation account already exists'
$accountPresent = (($accountPresentRaw -join [Environment]::NewLine).Trim())
$alreadyThere = -not [string]::IsNullOrWhiteSpace($accountPresent)
if ($alreadyThere) {
    throw "Automation account '$account' already exists. Use a new name to avoid modifying other scheduled jobs."
}
$now = [DateTime]::UtcNow
$start = $now.Date.AddHours(2).AddMinutes(30)
if ($start -le $now.AddMinutes(15)) { $start = $start.AddDays(1) }
Write-Host "`nSubscription: $subId`nResource group: $rg`nRegion: $region`nAutomation account: $account`nHTTPS endpoint: $($site):443`nWeekly warning at <=$warningDays days; daily at <=$escalationDays days`nSchedule: Daily from $($start.ToString('yyyy-MM-dd HH:mm')) UTC (08:00 IST)" -ForegroundColor Cyan
$confirmation = Read-Host 'Type DEPLOY to create the Azure Automation resources (anything else cancels)'
if ($confirmation -cne 'DEPLOY') { throw 'Cancelled. No Azure resource created.' }

# Preflight the webhook on your current machine if requested. Never print it.
if ($doTest) {
    $message = @{
        type='message'
        attachments=@(@{
            contentType='application/vnd.microsoft.card.adaptive';contentUrl=$null
            content=@{ '$schema'='http://adaptivecards.io/schemas/adaptive-card.json'; type='AdaptiveCard'; version='1.2'; body=@(@{type='TextBlock';text="SETUP TEST: Public TLS monitoring for $site";wrap=$true}) }
        })
    } | ConvertTo-Json -Depth 12 -Compress
    Invoke-RestMethod -Method Post -Uri $webhook -Body $message -ContentType 'application/json' -TimeoutSec 20 | Out-Null
    Write-Host 'OK: Teams accepted the setup message. Verify it appeared in your channel.' -ForegroundColor Green
}

Write-Host "`nEnsuring the Azure CLI Automation extension is available..." -ForegroundColor Cyan
& az extension show --name automation --output none 2>$null
if ($LASTEXITCODE -ne 0) {
    & az extension add --name automation --yes --output none
    Must-Succeed 'Install Azure CLI Automation extension'
}
else {
    Write-Host 'OK: Azure CLI Automation extension already installed.' -ForegroundColor Green
}

Write-Host "`nCreating an Azure Automation Free account..." -ForegroundColor Cyan
& az automation account create --name $account --resource-group $rg --location $region --sku Free --output none
Must-Succeed 'Create Azure Automation Free account'

# Azure Automation REST expects properties.value to itself be a JSON string literal.
# The file containing this value is temporary and removed immediately after submission.
$secretUrl = "https://management.azure.com$root/variables/CertExpiryTeamsWebhook?api-version=$api"
Put-Json $secretUrl @{ name='CertExpiryTeamsWebhook'; properties=@{
    description='Teams Workflows webhook for certificate alerts'; isEncrypted=$true
    value=($webhook | ConvertTo-Json -Compress)
}}
$webhook = $null

& az automation runbook create --automation-account-name $account --resource-group $rg --name $runbookName --type PowerShell --location $region --output none
Must-Succeed 'Create PowerShell runbook'
& az automation runbook replace-content --automation-account-name $account --resource-group $rg --name $runbookName --content "@$runbookFile" --output none
Must-Succeed 'Upload runbook content'
& az automation runbook publish --automation-account-name $account --resource-group $rg --name $runbookName --output none
Must-Succeed 'Publish runbook'

$schedUrl = "https://management.azure.com$root/schedules/$scheduleName`?api-version=$api"
Put-Json $schedUrl @{ name=$scheduleName; properties=@{
    description='Daily public HTTPS certificate expiry check (08:00 IST)'
    startTime=$start.ToString('yyyy-MM-ddTHH:mm:ssZ'); timeZone='UTC';
    frequency='Day'; interval=1
}}
$associationId = [guid]::NewGuid().ToString()
$jobUrl = "https://management.azure.com$root/jobSchedules/$associationId`?api-version=$api"
Put-Json $jobUrl @{ properties=@{
    schedule=@{name=$scheduleName}; runbook=@{name=$runbookName}
    parameters=@{ HostName=$site; WarningDays="$warningDays"; EscalationDays="$escalationDays" }
}}
Write-Host "`nCREATED: $account / $runbookName / $scheduleName" -ForegroundColor Green
Write-Host 'Go to Azure Portal > Automation Accounts > [account] > Runbooks > [runbook] > Jobs to see future results.'
Write-Host 'IMPORTANT: Start a manual test from the Azure portal, with SendTest=True, to verify the Azure-runbook Teams webhook.' -ForegroundColor Yellow
Write-Host 'Cost: Free Automation job minutes are shared at the subscription level. Check existing consumption; no paid alerts or Log Analytics resources were created.' -ForegroundColor Yellow
