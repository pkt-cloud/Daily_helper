# Public website TLS certificate-expiry monitoring (Azure Automation + Teams)

Designed to keep **new Azure charges at $0 within the existing subscription's unused 500 free Automation runbook minutes per month**, rather than creating billable Application Insights Standard tests. Not a guarantee: usage is shared across your subscription and specific subscription offers can differ. No VM or Azure DevOps hosted job is needed. This checks **the HTTPS certificate presented to public clients**, which may be a CDN/gateway certificate rather than App Service's uploaded certificate if TLS is terminated upstream.

## One-time preparation in Teams (required)

Open Microsoft Teams → Workflows → choose **Send webhook alerts to a channel** (or an equivalent channel incoming-webhook template) → choose team/channel → save → **copy the generated webhook URL**. Use a workflow trigger authentication option compatible with calls from Azure Automation. The template does not require a Power Automate premium license, according to Microsoft documentation. Keep this URL secret. If tenant policy prevents you from creating a workflow, ask your Teams administrator.

## Installation

Requires Windows PowerShell 5.1+ and Azure CLI 2.75+ (`az version`). You need permissions to create Azure Automation resources in an existing resource group. Azure CLI's `automation` extension is **experimental**, automatically installed on first use. If disabled by policy, ask your Azure administrator to approve it. No changes are made to your existing App Service or existing Application Insights resource.

Place both `.ps1` files in the same directory. Then in PowerShell:

```powershell
az login
Set-ExecutionPolicy -Scope Process Bypass
.\Deploy-CertExpiryMonitor.ps1
```

The script asks once for subscription, existing resource group, new automation account name, public hostname, Teams webhook URL and thresholds. It sends an optional webhook setup test and deploys a free Automation account, encrypted webhook variable, runbook and daily schedule. It refuses to overwrite an existing Automation account. A manual test from the **Azure runbook** after deployment is still required; local webhook success doesn't prove Azure Automation can reach your tenant's Teams workflow.

**Schedule:** Daily at 02:30 UTC = 08:00 IST. Above the configured warning threshold, no messages. Within the warning threshold, a weekly Monday Teams reminder. Within the escalation threshold, a daily Teams reminder. Expired/invalid/unreachable TLS produces a critical alert every run. Adjust thresholds when prompted (defaults 30 and 10 days). Depending on the exact time of certificate expiry, the calendar-day display rounds partial days upward.

## Validate

1. Verify the initial setup test appears in Teams.
2. Open Azure Portal → Automation Accounts → your new account → Runbooks → `Check-PublicTlsExpiry` → Start. Provide `HostName` and set `SendTest` to `True` for a Teams-only test. Then run a normal check with `SendTest=False`.
3. Check the runbook output and its daily linked schedule. Check costs/free-job-minute consumption after a week and set a budget if your subscription policy requires it. Alerts about runbook failures themselves are **not** included; consider independent operational monitoring for production.

## Avoid extra charges

Do not enable Log Analytics diagnostics or paid Azure Monitor alert rules for this deployment if strict cost control is required. Avoid Azure Automation Watchers (charged separately). Monitor total Automation free minutes used across **all** Automation accounts in the subscription.

## Security

The webhook is stored in an **encrypted** Azure Automation variable. The installer briefly writes the URL into a temporary local JSON request file and deletes it immediately after Azure accepts the request. Avoid PowerShell transcripts/CLI debug logging during setup, and restrict read access to the setup terminal. Rotate the webhook if exposed. Do not commit webhook URLs to source control.

## Constraints

The script is a deployable starter, but it has **not been run against your Azure tenant**. Azure subscriptions, organizations and versions differ. Run it first against a non-production hostname or monitoring resource group with approved privileges, review changes, and manually verify your Teams delivery. Azure CLI experimental `automation` extension may change.

## Azure CLI 2.82 / Windows PowerShell note

This package avoids using `az version --query '"azure-cli"'`, which can lose the JMESPath quotes in Windows PowerShell. The installer reads `az version --output json` and parses the JSON with PowerShell instead.
