#requires -version 5.1
<#
.SYNOPSIS
  Guarded disk cleanup for the Azure Windows VM hosting FIRST-DEV and two Azure DevOps agents.
.DESCRIPTION
  Preview is the default. The script deletes only allowlisted temporary content and
  old timestamped FIRST-DEV backups. It does NOT clean Visual Studio installer caches,
  remove SDKs, touch IIS application files, or delete agent working directories.
  Run on the VM through the dedicated, pinned Azure DevOps maintenance pipeline.
#>
[CmdletBinding()]
param(
    [ValidateSet('Preview','Cleanup')][string]$Mode = 'Preview',
    [ValidateSet('Validated','Aggressive')][string]$Level = 'Aggressive',
    [Parameter(Mandatory = $true)][string]$ReportDirectory,
    [ValidateRange(1,100)][int]$MinimumFreeGiB = 20,
    [ValidateRange(1,500)][int]$TargetFreeGiB = 25,
    [ValidateRange(1,365)][int]$BackupDays = 30,
    [ValidateRange(1,50)][int]$KeepNewestBackups = 5,
    [ValidateRange(1,180)][int]$VsResidueHours = 24,
    [ValidateRange(1,365)][int]$UserTempDays = 14,
    [ValidateRange(1,365)][int]$WindowsTempDays = 30,
    [ValidateRange(1,365)][int]$AgentTempDays = 7
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# These were verified on this VM. Do not add generic Program Files/ProgramData paths.
$BackupRoot = 'C:\inetpub\backups'
$AppRoot = 'C:\inetpub\FIRST-DEV'
$AgentRoots = @('C:\agent', 'C:\azagent\A1')
$UserTempRoots = @(
    'C:\Users\dhamodharan.subraman\AppData\Local\Temp',
    'C:\Users\pavankumar.thippeswa\AppData\Local\Temp'
)
$WindowsTempRoot = 'C:\Windows\Temp'
$UpdaterTaskPath = '\Microsoft\VisualStudio\Updates\'
$UpdaterTaskName = 'BackgroundDownload'
$DownloaderMarker = 'resources\app\ServiceHub\Services\Microsoft.VisualStudio.Setup.Service\BackgroundDownload.exe'
$script:Rows = New-Object 'System.Collections.Generic.List[object]'
$script:Notes = New-Object 'System.Collections.Generic.List[string]'
$script:RemovedCount = 0
$script:FailedCount = 0
$script:ReclaimEstimate = [int64]0
$script:Outcome = 'Success'
$script:FailureReason = ''
$script:Before = $null
$script:After = $null
$script:UpdaterState = 'Not checked'
$script:Mutex = $null
$script:LockHeld = $false

function Write-Note([string]$Message) {
    $script:Notes.Add($Message)
    Write-Host "[VM2] $Message"
}
function Write-Issue([string]$Message) {
    $text = $Message -replace '[\r\n]+',' '
    Write-Warning $text
    Write-Host "##vso[task.logissue type=warning]$text"
    $script:Notes.Add("WARNING: $text")
}
function Get-FreeGiB {
    $volume = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
    if (-not $volume) { throw 'Cannot read C: volume.' }
    return [math]::Round([double]$volume.FreeSpace / 1GB, 3)
}
function Assert-InScope([string]$Target,[string]$Root) {
    $base = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $full = [IO.Path]::GetFullPath($Target).TrimEnd('\')
    if (-not $full.StartsWith(($base + '\'),[StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing target outside approved root: $full"
    }
    $rootItem = Get-Item -LiteralPath $base -Force -ErrorAction Stop
    if (($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Approved root itself is a reparse point: $base"
    }
}
function Inspect-Item([string]$Target) {
    # Enumerate without descending into any reparse point. If found, refuse the entire tree.
    $entry = Get-Item -LiteralPath $Target -Force -ErrorAction Stop
    $stack = New-Object 'System.Collections.Generic.Stack[object]'
    $stack.Push($entry)
    $bytes = [int64]0
    $lastUtc = [datetime]::MinValue
    while ($stack.Count -gt 0) {
        $node = $stack.Pop()
        if (($node.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse point inside candidate: $($node.FullName)"
        }
        if ($node.LastWriteTimeUtc -gt $lastUtc) { $lastUtc = $node.LastWriteTimeUtc }
        if ($node.PSIsContainer) {
            foreach ($child in @(Get-ChildItem -LiteralPath $node.FullName -Force -ErrorAction Stop)) {
                $stack.Push($child)
            }
        } else {
            $bytes += [int64]$node.Length
        }
    }
    return [PSCustomObject]@{ Bytes = $bytes; MostRecentUtc = $lastUtc }
}
function Add-Result([string]$Category,[string]$Target,[string]$Action,[string]$Reason,
                    [int64]$Bytes = 0,[datetime]$MostRecent = [datetime]::MinValue) {
    $script:Rows.Add([PSCustomObject]@{
        Category = $Category
        Path = $Target
        Action = $Action
        EstimatedGiB = [math]::Round([double]$Bytes/1GB,4)
        MostRecentWriteUtc = if ($MostRecent -eq [datetime]::MinValue) { '' } else { $MostRecent.ToString('s') + 'Z' }
        Reason = $Reason
    })
}
function Consider-Deletion([string]$Category,[string]$Target,[string]$ApprovedRoot,
                           [datetime]$MustBeOlderThan,[string]$Reason) {
    try {
        Assert-InScope -Target $Target -Root $ApprovedRoot
        if (-not (Test-Path -LiteralPath $Target)) { return }
        $stats = Inspect-Item -Target $Target
        if ($stats.MostRecentUtc -ge $MustBeOlderThan) {
            # Only show a subset of excluded candidates; full report is audit-friendly.
            Add-Result $Category $Target 'PreservedRecent' $Reason $stats.Bytes $stats.MostRecentUtc
            return
        }
        $script:ReclaimEstimate += $stats.Bytes
        if ($Mode -eq 'Preview') {
            Add-Result $Category $Target 'WouldDelete' $Reason $stats.Bytes $stats.MostRecentUtc
        } else {
            # The item may have changed since inspection; check freshness again.
            $latest = Inspect-Item -Target $Target
            if ($latest.MostRecentUtc -ge $MustBeOlderThan) {
                Add-Result $Category $Target 'PreservedChanged' 'Modified during scan' $latest.Bytes $latest.MostRecentUtc
                return
            }
            Remove-Item -LiteralPath $Target -Recurse -Force -ErrorAction Stop
            $script:RemovedCount++
            Add-Result $Category $Target 'Deleted' $Reason $latest.Bytes $latest.MostRecentUtc
        }
    } catch {
        $script:FailedCount++
        Add-Result $Category $Target 'SkippedError' $_.Exception.Message
        Write-Issue "Skipped $Category candidate due to access, lock or safety check: $Target"
    }
}
function Get-ActiveActivities {
    $names = @('Agent.Worker.exe','MSBuild.exe','VBCSCompiler.exe','VSTest.Console.exe',
               'dotnet.exe','NuGet.exe','devenv.exe','msiexec.exe','TiWorker.exe',
               'TrustedInstaller.exe','dism.exe','vs_installer.exe','VSInstaller.exe',
               'BackgroundDownload.exe','cl.exe','csc.exe','SqlPackage.exe')
    return @(Get-CimInstance Win32_Process -ErrorAction Stop |
        Where-Object { $names -contains $_.Name } |
        Select-Object Name,ProcessId,ExecutablePath)
}
function Assert-SafeToClean {
    $found = @(Get-ActiveActivities)
    $workers = @($found | Where-Object { $_.Name -ieq 'Agent.Worker.exe' })
    $busy = @($found | Where-Object { $_.Name -ine 'Agent.Worker.exe' })
    $workerCount = $workers.Count
    if ($workerCount -ne 1) {
        throw "Expected one maintenance Agent.Worker.exe, found $workerCount; another job may be running."
    }
    $home = $env:AGENT_HOMEDIRECTORY
    if ([string]::IsNullOrWhiteSpace($home)) {
        throw 'AGENT_HOMEDIRECTORY not provided: cleanup must run inside the target Azure DevOps agent.'
    }
    $expectedBin = [IO.Path]::GetFullPath((Join-Path $home 'bin')).TrimEnd('\') + '\'
    $actualWorker = [string]$workers[0].ExecutablePath
    if (-not $actualWorker.StartsWith($expectedBin,[StringComparison]::OrdinalIgnoreCase)) {
        throw "Detected worker does not belong to this maintenance agent: $actualWorker"
    }
    if ($busy.Count -gt 0) {
        $names = ($busy | Select-Object -ExpandProperty Name -Unique) -join ', '
        throw "Active build/installer processes: $names"
    }
}
function Clean-IisBackups {
    if (-not (Test-Path -LiteralPath $BackupRoot -PathType Container)) {
        Write-Issue "IIS backup folder not found: $BackupRoot"
        return
    }
    $all = @(
        Get-ChildItem -LiteralPath $BackupRoot -Directory -Force -ErrorAction Stop |
        Where-Object { $_.Name -match '^FIRST-DEV-\d{8}-\d{6}$' } |
        Sort-Object Name -Descending
    )
    $keep = @($all | Select-Object -First $KeepNewestBackups | ForEach-Object { $_.FullName })
    $cutoff = [datetime]::UtcNow.AddDays(-$BackupDays)
    foreach ($item in $all) {
        if ($keep -contains $item.FullName) {
            Add-Result 'IISBackups' $item.FullName 'PreservedNewest' "Preserve last $KeepNewestBackups backups"
            continue
        }
        Consider-Deletion 'IISBackups' $item.FullName $BackupRoot $cutoff `
            "Over $BackupDays days old, except latest $KeepNewestBackups"
    }
    Write-Note "IIS backup folders matching approved naming pattern: $($all.Count)"
}
function Clean-VsDownloaderResidue {
    $task = Get-ScheduledTask -TaskPath $UpdaterTaskPath -TaskName $UpdaterTaskName -ErrorAction SilentlyContinue
    if (-not $task) {
        Write-Issue 'Visual Studio BackgroundDownload scheduled task not found; downloader cleanup skipped.'
        return
    }
    $originalState = [string]$task.State
    $disabledByUs = $false
    $restoreMarker = Join-Path $ReportDirectory 'VSUpdater-NeedsRestore.marker'
    try {
        if ($Mode -eq 'Cleanup' -and $originalState -ne 'Disabled') {
            if ($originalState -eq 'Running') {
                Write-Issue 'Visual Studio BackgroundDownload task is running; downloader cleanup skipped.'
                return
            }
            # Persist intent before disabling so a separate always() pipeline step can
            # recover the task if PowerShell or the pipeline is interrupted.
            New-Item -ItemType Directory -Path $ReportDirectory -Force -ErrorAction Stop | Out-Null
            'PreviouslyEnabled' | Set-Content -LiteralPath $restoreMarker -Encoding ASCII -ErrorAction Stop
            Disable-ScheduledTask -TaskPath $UpdaterTaskPath -TaskName $UpdaterTaskName -ErrorAction Stop | Out-Null
            $disabledByUs = $true
            Write-Note 'Temporarily disabled Visual Studio background download task.'
            # Check again after disabling to close the launch race.
            Assert-SafeToClean
        }
        $cutoff = [datetime]::UtcNow.AddHours(-$VsResidueHours)
        foreach ($root in $UserTempRoots) {
            if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
            $parents = @($root, (Join-Path $root 'delete'))
            foreach ($parent in $parents) {
                if (-not (Test-Path -LiteralPath $parent -PathType Container)) { continue }
                if ($parent -ne $root) {
                    $parentItem = Get-Item -LiteralPath $parent -Force
                    if (($parentItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                }
                foreach ($folder in @(Get-ChildItem -LiteralPath $parent -Directory -Force -ErrorAction Stop)) {
                    if (($folder.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                    $marker = Join-Path $folder.FullName $DownloaderMarker
                    if (Test-Path -LiteralPath $marker -PathType Leaf) {
                        Consider-Deletion 'VSDownloaderResidue' $folder.FullName $root $cutoff `
                            'Known Visual Studio BackgroundDownload extraction signature'
                    }
                }
            }
        }
    } finally {
        if ($disabledByUs) {
            try {
                Enable-ScheduledTask -TaskPath $UpdaterTaskPath -TaskName $UpdaterTaskName -ErrorAction Stop | Out-Null
                Write-Note 'Restored Visual Studio BackgroundDownload task to enabled state.'
                if (Test-Path -LiteralPath $restoreMarker) {
                    Remove-Item -LiteralPath $restoreMarker -Force -ErrorAction Stop
                }
            } catch {
                Write-Issue 'URGENT: Failed to restore Visual Studio BackgroundDownload task; check Task Scheduler manually.'
                throw
            }
        }
    }
}
function Clean-StaleTopLevel([string]$Category,[string]$Root,[int]$AgeDays,
                             [string[]]$ExcludeNames = @()) {
    if (-not (Test-Path -LiteralPath $Root -PathType Container)) { return }
    $cutoff = [datetime]::UtcNow.AddDays(-$AgeDays)
    foreach ($entry in @(Get-ChildItem -LiteralPath $Root -Force -ErrorAction Stop)) {
        if ($ExcludeNames -contains $entry.Name) { continue }
        # Never consider links, junctions or reparse-root children.
        if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
        Consider-Deletion $Category $entry.FullName $Root $cutoff "All contents older than $AgeDays days"
    }
}
function Save-Report {
    New-Item -ItemType Directory -Path $ReportDirectory -Force -ErrorAction Stop | Out-Null
    $script:After = Get-FreeGiB
    $csvPath = Join-Path $ReportDirectory 'VM2-Cleanup-Candidates.csv'
    $summaryPath = Join-Path $ReportDirectory 'VM2-Cleanup-Summary.json'
    if ($script:Rows.Count -gt 0) {
        $script:Rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath
    } else {
        'Category,Path,Action,EstimatedGiB,MostRecentWriteUtc,Reason' | Set-Content -Path $csvPath -Encoding UTF8
    }
    if ($script:After -lt $TargetFreeGiB) {
        Write-Issue "C: is below preferred target ($TargetFreeGiB GiB); currently $($script:After) GiB."
    }
    if ($script:After -lt $MinimumFreeGiB) {
        Write-Issue "C: is below minimum ($MinimumFreeGiB GiB); currently $($script:After) GiB."
    }
    $netChange = $null
    if ($null -ne $script:Before) {
        $netChange = [math]::Round(($script:After - $script:Before),3)
    }
    $status = [ordered]@{
        Machine = $env:COMPUTERNAME
        UtcTime = [datetime]::UtcNow.ToString('s') + 'Z'
        Mode = $Mode
        Level = $Level
        Outcome = $script:Outcome
        FailureReason = $script:FailureReason
        FreeBeforeGiB = $script:Before
        FreeAfterGiB = $script:After
        NetFreeChangeGiB = $netChange
        MinimumFreeGiB = $MinimumFreeGiB
        TargetFreeGiB = $TargetFreeGiB
        CandidateGiB = [math]::Round([double]$script:ReclaimEstimate/1GB,3)
        DeletedItems = $script:RemovedCount
        SkippedErrors = $script:FailedCount
        Findings = $script:Rows.Count
        Notes = @($script:Notes.ToArray())
    }
    $status | ConvertTo-Json -Depth 5 | Set-Content -Path $summaryPath -Encoding UTF8
    Write-Host '========== VM2 CLEANUP REPORT =========='
    Write-Host "Execution mode    : $Mode / $Level"
    Write-Host "Outcome           : $($script:Outcome)"
    Write-Host "C: free before    : $($script:Before) GiB"
    Write-Host "C: free after     : $($script:After) GiB"
    Write-Host "Candidate total   : $($status.CandidateGiB) GiB (logical size, not guaranteed free space)"
    Write-Host "Deleted items     : $($script:RemovedCount)"
    Write-Host "Skipped errors    : $($script:FailedCount)"
    Write-Host "Summary JSON      : $summaryPath"
    Write-Host "Detailed CSV      : $csvPath"
    $top = @($script:Rows | Where-Object { $_.Action -in @('WouldDelete','Deleted') } |
        Sort-Object EstimatedGiB -Descending | Select-Object -First 10)
    if ($top.Count -gt 0) {
        Write-Host 'Largest eligible items:'
        $top | Select-Object Category,EstimatedGiB,Action,Path | Format-Table -AutoSize -Wrap | Out-String | Write-Host
    }

}

try {
    $script:Before = Get-FreeGiB
    if (-not (Test-Path -LiteralPath $AppRoot -PathType Container)) {
        throw "Host guard failed: expected IIS app directory missing: $AppRoot"
    }
    foreach ($agent in $AgentRoots) {
        if (-not (Test-Path -LiteralPath (Join-Path $agent 'bin\Agent.Listener.exe') -PathType Leaf)) {
            throw "Host guard failed: expected agent missing: $agent"
        }
    }
    if ($Mode -eq 'Cleanup') {
        if ($env:AGENT_NAME -ine 'PROD-AGENT-VM-2') {
            throw "Host guard failed: expected Azure agent PROD-AGENT-VM-2, actual: $($env:AGENT_NAME)"
        }
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
            throw 'Cleanup requires an elevated Windows administrator token on the agent service account.'
        }
    }
    $script:Mutex = [System.Threading.Mutex]::new($false, 'Global\VM2DiskCleanupGuard')
    try { $script:LockHeld = $script:Mutex.WaitOne(0) }
    catch [System.Threading.AbandonedMutexException] { $script:LockHeld = $true }
    if (-not $script:LockHeld) { throw 'Another VM2 cleanup process is already running.' }

    if ($Mode -eq 'Cleanup') {
        Assert-SafeToClean
    } else {
        try { Assert-SafeToClean }
        catch { Write-Issue "Preview only: a cleanup execution would currently be blocked: $($_.Exception.Message)" }
    }
    Write-Note "Started on $env:COMPUTERNAME; mode=$Mode; level=$Level; free C:=$($script:Before) GiB"
    Write-Note 'Category: IIS backups'
    Clean-IisBackups
    Write-Note 'Category: signed Visual Studio downloader leftovers'
    Clean-VsDownloaderResidue
    if ($Level -eq 'Aggressive') {
        if ($Mode -eq 'Cleanup') { Assert-SafeToClean }
        Write-Note 'Category: old user Temp entries'

        foreach ($root in $UserTempRoots) {
            # Explicitly preserve Temp\delete (including its '3' and 'VS' subfolders),
            # and VS updater root because it may contain non-signature installer state.
            Clean-StaleTopLevel 'UserTemp' $root $UserTempDays @('delete','VS')
        }
        if ($Mode -eq 'Cleanup') { Assert-SafeToClean }
        Write-Note 'Category: old Windows Temp entries'
        Clean-StaleTopLevel 'WindowsTemp' $WindowsTempRoot $WindowsTempDays
        if ($Mode -eq 'Cleanup') { Assert-SafeToClean }
        Write-Note 'Category: old agent job Temp entries'
        foreach ($agent in $AgentRoots) {
            Clean-StaleTopLevel 'AgentJobTemp' (Join-Path $agent '_work\_temp') $AgentTempDays
        }
    }
} catch {
    $script:Outcome = 'Failed'
    $script:FailureReason = $_.Exception.Message
    Write-Issue "Maintenance could not complete: $($script:FailureReason)"
} finally {
    try { Save-Report }
    catch { Write-Warning "Unable to save cleanup report: $($_.Exception.Message)"; $script:Outcome = 'Failed' }
    if ($script:LockHeld -and $null -ne $script:Mutex) {
        try { $script:Mutex.ReleaseMutex() } catch {}
    }
    if ($null -ne $script:Mutex) { $script:Mutex.Dispose() }
}
if ($script:Outcome -eq 'Failed') { exit 1 }
if ($Mode -eq 'Cleanup' -and $script:After -lt $MinimumFreeGiB) { exit 2 }
exit 0
