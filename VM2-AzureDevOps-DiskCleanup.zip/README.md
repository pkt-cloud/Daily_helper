# VM2 Azure DevOps disk cleanup

## Scope and design

- Target host is the Windows VM with two agents at `C:\agent` and `C:\azagent\A1` and the IIS app at `C:\inetpub\FIRST-DEV`.
- Default pipeline execution is **Preview** (no deletions). The daily schedule also runs Preview until you explicitly change the YAML default after testing.
- `Validated` removes only old timestamped IIS backup directories and uniquely identifiable Visual Studio BackgroundDownload extraction leftovers.
- `Aggressive` additionally removes stale content **at the immediate child level only**, provided the candidate tree contains no newer content or reparse points, from these known directories:
  - Two specified users' `AppData\Local\Temp`, 14-day retention (excludes top-level `delete` and `VS`).
  - `C:\Windows\Temp`, 30-day retention.
  - Both agents' `_work\_temp`, 7-day retention.
- IIS backups: only `FIRST-DEV-YYYYMMDD-HHmmss` directories, older than 30 days by most recent item write, and always retain latest five timestamp-named backups.
- VS updater remnants: only directories bearing the known `resources\app\ServiceHub\Services\Microsoft.VisualStudio.Setup.Service\BackgroundDownload.exe` marker, with every item unchanged for more than 24 hours. Temporarily disable the scheduled updater during Cleanup and restore it in a `finally` block. An independent `always()` pipeline step also attempts recovery if the script was interrupted; unexpected VM shutdowns still require manual Task Scheduler verification.
- The script refuses Cleanup if it detects other agent jobs, builds or installers; the script itself runs as one agent worker. Admin privileges required.
- It logs every considered candidate to a CSV and summary JSON as pipeline artifacts. It reports measured disk free space before and after; candidate logical bytes are only an *estimate*.
- It emits Azure DevOps warnings for under-target free space; Cleanup exits with code 2 if disk remains below 20 GiB.

## Never cleaned by this script

`C:\inetpub\FIRST-DEV`, `C:\inetpub\wwwroot`, `C:\ProgramData\Microsoft\VisualStudio\Packages`, `C:\Windows\WinSxS`, `C:\Windows\Installer`, `C:\agent\_work` except `_temp`, `C:\azagent\A1\_work` except `_temp`, .NET/SDK/Visual Studio installed components, IIS/agent services, IIS web logs, Defender/Sentinel/ManageEngine/FortiClient.

The known old random folder `qigrzfe4` was removed manually in the previous maintenance. This pipeline **does not** delete future random VS staging folders without an established signature unless they qualify under the separate 14-day user Temp policy. VS installer cache optimization via `--nocache` and workload uninstall are **not automated**.

## Installation in Azure DevOps

1. Commit `azure-pipelines.vm2-disk-cleanup.yml` and `scripts/Invoke-VM2DiskCleanup.ps1` in the same repository, preserving relative paths. Use `main` branch or update the schedule branch.
2. In the Azure DevOps portal verify the **actual pool** for `PROD-AGENT-VM-2` and update `pool.name` (the service naming suggests `DEV-IIS`, but verify). The `Agent.Name` demand pins the job to that agent.
3. Create a new YAML pipeline pointing at `azure-pipelines.vm2-disk-cleanup.yml`. Disable UI-defined schedules if you want the YAML schedule to apply.
4. Agent service account must have elevated administrative permissions to delete profile Temp content, IIS backup directories and Windows Temp, and access the Task Scheduler VS updater task. Windows service accounts with insufficient permissions will fail before Cleanup; don't elevate the whole agent service account without security approval.
5. Manually run **Preview / Aggressive**, download `VM2-DiskCleanup-Report`, and review `VM2-Cleanup-Candidates.csv` for any path that should be excluded. Confirm that the report shows the expected host and paths.
6. Run **Cleanup / Validated** once in an agreed maintenance window. Verify both agent services, updater task and FIRST-DEV endpoint, and inspect the report.
7. Run **Cleanup / Aggressive** only after reviewing the full Preview candidate list. Check outcomes, disk free space, and application health.
8. To activate **scheduled deletion**, change the parameter `mode` **default** from `Preview` to `Cleanup` in the YAML and commit. With Preview as the default, the daily schedule only audits. YAML schedule uses UTC (`30 7 * * *`). Do not add a second UI-defined schedule without removing the YAML schedule.
9. Set pipeline failure notifications / Azure Monitor disk alerts independently; the pipeline is a periodic cleanup job, not 24-hour real-time protection. Keep Azure DevOps native agent pool maintenance jobs for source/workspace retention.

## Known limitations

- The script cannot establish whether a file is semantically needed by a program; it relies on strict known paths, time-based retention and no-active-job checks.
- A candidate is skipped if its directory contains recent content, a reparse point or unreadable entries, which is deliberate.
- Already-open files, permission errors, antivirus interventions or installation updates can cause partial removals. The report includes `SkippedError` rows. No service is stopped or restarted.
- External build pipelines or other remote use of this VM may not be visible in process checks. Schedule during a known idle period.
- Recovered bytes are not guaranteed: hardlinks, filesystem compression and other processes can change the disk reading.
- Pipeline checkout and diagnostic reporting can temporarily consume a little disk space.
- If scheduled jobs run on an Azure DevOps Services organization, `PublishPipelineArtifact@1` works; on Azure DevOps Server, replace it with `PublishBuildArtifacts@1`.
