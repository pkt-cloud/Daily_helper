# Azure Automation PowerShell runbook. No Azure identity required: checks public TLS endpoint.
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[a-zA-Z0-9.-]+$')]
    [string] $HostName,
    [int] $WarningDays = 30,
    [int] $EscalationDays = 10,
    [switch] $SendTest
)
$ErrorActionPreference = 'Stop'
$Webhook = Get-AutomationVariable -Name 'CertExpiryTeamsWebhook'
if ([string]::IsNullOrWhiteSpace($Webhook)) { throw 'Missing encrypted Automation variable: CertExpiryTeamsWebhook' }

function Send-TeamsAlert {
    param([string]$Heading, [string]$Message)
    # Teams Workflows 'Send webhook alerts to a channel' template accepts adaptive-card messages.
    $card = @{
        type = 'message'
        attachments = @(@{
            contentType = 'application/vnd.microsoft.card.adaptive'
            contentUrl  = $null
            content     = @{
                '$schema' = 'http://adaptivecards.io/schemas/adaptive-card.json'
                type      = 'AdaptiveCard'
                version   = '1.2'
                body      = @(
                    @{ type = 'TextBlock'; size = 'Medium'; weight = 'Bolder'; text = $Heading; wrap = $true },
                    @{ type = 'TextBlock'; text = $Message; wrap = $true }
                )
            }
        })
    }
    $json = $card | ConvertTo-Json -Depth 12 -Compress
    Invoke-RestMethod -Method Post -Uri $Webhook -Body $json -ContentType 'application/json' -TimeoutSec 20 | Out-Null
}

if ($SendTest) {
    Send-TeamsAlert -Heading 'Certificate monitor: test' -Message "Test message for $HostName from Azure Automation."
    Write-Output 'TEST: Teams notification sent.'
    return
}

$tcp = $null
$ssl = $null
try {
    $tcp = [System.Net.Sockets.TcpClient]::new()
    $connect = $tcp.ConnectAsync($HostName, 443)
    if (-not $connect.Wait(15000)) { throw 'TCP connection timed out after 15 seconds' }
    $connect.GetAwaiter().GetResult()

    $tlsErrors = [System.Net.Security.SslPolicyErrors]::None
    $callback = [System.Net.Security.RemoteCertificateValidationCallback] {
        param($sender, $cert, $chain, $errors)
        $script:observedTlsErrors = $errors
        # Inspect an expired/broken certificate as well. Any TLS policy error triggers an alert below.
        return $true
    }
    $ssl = [System.Net.Security.SslStream]::new($tcp.GetStream(), $false, $callback)
    $ssl.ReadTimeout = 15000
    $ssl.WriteTimeout = 15000
    $script:observedTlsErrors = [System.Net.Security.SslPolicyErrors]::None
    $ssl.AuthenticateAsClient($HostName)
    if (-not $ssl.RemoteCertificate) { throw 'Server did not present a certificate.' }

    $leaf = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($ssl.RemoteCertificate)
    $remaining = ($leaf.NotAfter.ToUniversalTime() - [DateTime]::UtcNow).TotalDays
    $days = [int][Math]::Ceiling($remaining)
    $expiry = $leaf.NotAfter.ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss UTC')
    Write-Output "HOST=$HostName EXPIRY=$expiry DAYS_REMAINING=$days THUMBPRINT=$($leaf.Thumbprint) TLS_ERRORS=$script:observedTlsErrors"

    if ($script:observedTlsErrors -ne [System.Net.Security.SslPolicyErrors]::None) {
        Send-TeamsAlert -Heading 'CRITICAL: TLS certificate validation issue' -Message "$HostName presented a certificate with TLS errors: $script:observedTlsErrors. Expiry: $expiry."
        throw "TLS policy errors: $script:observedTlsErrors"
    }
    if ($remaining -le 0) {
        Send-TeamsAlert -Heading 'CRITICAL: HTTPS certificate expired' -Message "$HostName certificate expired: $expiry. Investigate immediately."
        throw "Certificate expired on $expiry"
    }
    if ($remaining -le $EscalationDays) {
        Send-TeamsAlert -Heading 'HIGH: HTTPS certificate renewal needed' -Message "$HostName certificate expires in $days day(s), at $expiry."
        Write-Warning "HIGH: expiry within $EscalationDays days"
    }
    elseif ($remaining -le $WarningDays) {
        # Weekly early reminders, then daily inside the escalation window.
        if ([DateTime]::UtcNow.DayOfWeek -eq [DayOfWeek]::Monday) {
            Send-TeamsAlert -Heading 'WARNING: HTTPS certificate renewal planning' -Message "$HostName certificate expires in $days day(s), at $expiry."
        }
        Write-Warning "WARNING: expiry within $WarningDays days"
    }
    else {
        Write-Output "OK: expiry is more than $WarningDays days away."
    }
}
catch {
    $reason = $_.Exception.Message
    if ($reason -notlike 'TLS policy errors:*' -and $reason -notlike 'Certificate expired on *') {
        Write-Warning 'Certificate check failed. Sending an operational alert to Teams.'
        Send-TeamsAlert -Heading 'CRITICAL: HTTPS certificate check failed' -Message "Could not verify ${HostName}: $reason"
    }
    throw
}
finally {
    if ($ssl) { $ssl.Dispose() }
    if ($tcp) { $tcp.Dispose() }
}
